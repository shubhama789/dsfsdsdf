package com.cg.insurance.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.insurance.bean.ClaimBean;
import com.cg.insurance.bean.UserBean;
import com.cg.insurance.exception.InsuranceClaimException;

public interface IInsuranceService {

	//boolean validateDetails(ClaimBean claimBean) throws InsuranceClaimException;

	String checkAccess(UserBean userbean) throws IOException, SQLException, InsuranceClaimException;

	void addUser(UserBean userbean) throws InsuranceClaimException, IOException;

	List<ClaimBean> viewAllClaims(String name) throws InsuranceClaimException, IOException, SQLException;

	


}
