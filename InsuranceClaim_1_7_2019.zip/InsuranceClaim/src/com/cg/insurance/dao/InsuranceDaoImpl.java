package com.cg.insurance.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.cg.insurance.bean.ClaimBean;
import com.cg.insurance.bean.UserBean;
import com.cg.insurance.exception.InsuranceClaimException;
import com.cg.insurance.util.DbConnection;

public class InsuranceDaoImpl implements  IInsuranceDAO {
static UserBean userBean=null;
static Connection connection=null;



	@Override
	public String checkAccess(UserBean userbean) throws IOException, SQLException, InsuranceClaimException {
		
		PreparedStatement statement=null;
		String message=null;
		String user=null;
		String pass = null;
		String role =null;
		try {
			 connection = DbConnection.getConnection();
			 
			 statement=connection.prepareStatement(QueryMappers.checkAccess);
			 statement.setString(1,userbean.getUsername());
			 //statement.executeUpdate();
			 
			
			 ResultSet resultSet = statement.executeQuery();
			 while(resultSet.next()) {
				 user = resultSet.getString(1);
				 pass = resultSet.getString(2);
				 role = resultSet.getString(3);
			 }
			
			 if(user!=null) {
					if(pass.equals(userbean.getPassword())) {
						return role;
					}
					else {
						message="wrong password";
						//throw new InsuranceClaimException("wrong password");
					}
			 }
			 else {
				 message="NO such User Exists!!";
				 	//throw new InsuranceClaimException("NO such User Exists!!");
				 
				}
			 if(message!=null) {
				 throw new InsuranceClaimException(message);
			 }
			 
			
		} catch (NullPointerException e) {
			
			//throw new InsuranceClaimException("There are no records of User");
		}
		finally
		{
				try 
				{
					statement=null;
					userbean=null;
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					
					throw new InsuranceClaimException("Error in closing db connection");

				}
		}
		return role;
	}

	@Override
	public void addUser(UserBean userbean) throws InsuranceClaimException, IOException {
		connection = DbConnection.getConnection();
		PreparedStatement pst = null;
		
		
		try {
			
			pst = connection.prepareStatement(QueryMappers.insert_User);
			pst.setString(1,userbean.getUsername());
			pst.setString(2,userbean.getPassword());
			pst.setString(3,userbean.getRoleCode());
			
			
			pst.executeUpdate();
			
		}
		catch(SQLException sqlException)
		{
				
				throw new InsuranceClaimException("Problem in Inserting Project in database!!");
		}
			
		finally
		{
				try 
				{
					
					pst.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					
					
					throw new InsuranceClaimException("Error in closing db connection");

				}
		}
		
	}

	@Override
	public List<ClaimBean> viewAllClaims(String userName) throws InsuranceClaimException, IOException, SQLException {

		Connection connection = DbConnection.getConnection();
		String name = null;
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery(QueryMappers.selectQuery);
		while (resultSet.next()) {
			name = resultSet.getString(1);

			if (userName.equals(name)) {
				name = userName;
				break;
			}

		}

		List<ClaimBean> claimList = new ArrayList<ClaimBean>();
		if (userName.equals(name)) {
			try {
				PreparedStatement ps = connection.prepareStatement(QueryMappers.viewAllClaims);
				ps.setString(1, name);
				ps.executeUpdate();
				resultSet = ps.executeQuery();
				if (resultSet == null) {
					throw new InsuranceClaimException("There are no claims...");
				} else {
					while (resultSet.next()) {
						ClaimBean claim = new ClaimBean();
						claim.setClaimNumber(resultSet.getLong(1));
						claim.setClaimType(resultSet.getString(2));
						claim.setPolicyNumber(resultSet.getLong(3));
						claimList.add(claim);
					}
					return claimList;
				}
			} catch (Exception e) {
				//logger.error(e.getMessage());
				//e.printStackTrace();
				throw new InsuranceClaimException("problem has occured");
			}
			finally {
				connection.close();
			}
			
			} else {
			System.out.println("user name is not found IN DATABASE");
			throw new InsuranceClaimException("user name is not found");
		}
		// return claimList;

	}

		
	
	
	
	
//	@Override
//	public int getPolicy_Number(InsuranceClaimBean insuranceClaimBean) throws SQLException, InsuranceClaimException {
//		insuranceClaimBean=new InsuranceClaimBean();
//		
//		PreparedStatement statement=null;
//		int policy_Number=0;
//		
//		try {
//			 connection = DbConnection.getConnection();
//			 statement=connection.prepareStatement(QueryMappers.insertQuery);
//			 statement.setLong(1, insuranceClaimBean.getClaim_Number());
//			 statement.setString(2, insuranceClaimBean.getClaim_Reason());
//			 statement.setString(3, insuranceClaimBean.getAccident_Location());
//			 statement.setString(4, insuranceClaimBean.getAccident_City());
//			 statement.setString(5, insuranceClaimBean.getAccident_State());
//			 statement.setLong(6, insuranceClaimBean.getAccident_Zip());
//			 statement.setString(7, insuranceClaimBean.getClaim_Type());
//			 statement.setLong(8, insuranceClaimBean.getPolicy_Number());
//			 
//			 statement.executeUpdate();
//			 statement =connection.prepareStatement(QueryMappers.getpolicy_number);
//			 ResultSet resultSet = statement.executeQuery();
//			 resultSet.next();
//			 policy_Number=resultSet.getInt(8);	
//			
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}		
//		
//		return policy_Number;
//	}

}
