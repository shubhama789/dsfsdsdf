package com.cg.insurance.dao;

public interface QueryMappers {
	public static final String insertQuery="insert into claim(?,?,?,?,?,?,?,?)";
	public static final String getpolicy_number="select  POLICY_NUMBER from claim;";
	public static final String checkAccess="select * from user_role where user_name=?";
	public static final String insert_User="insert into user_role values(?,?,?)";
	public static final String selectQuery="select user_name from user_role";
	public static final String viewAllClaims=" select claim_number, claim_type, policy_number from claim where policy_number IN (select policy_number from policy where account_number IN (select account_number from account where user_name =?))";
}
